from flask import Flask
from flask import url_for
from flask import request
from flask import render_template
from flask import redirect
import urllib.request
from PIL import Image
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired
import json
from pickle import loads, dumps
data = open("news.json", encoding="utf-8").read()
resp = json.loads(data)
print (resp[0]['login'])
class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/')
@app.route('/news')
def news():
    with open("news.json", "rt", encoding="utf8") as f:
        news_list = json.loads(f.read())
    print(news_list)
    return render_template('news.html', news=news_list)
@app.route('/login', methods=['GET', 'POST'])
def login():
    global form
    if request.method == 'GET':
        form = LoginForm()
        return render_template('login.html', title='Авторизация', form=form)
    elif request.method == 'POST':
       use=False
       login=request.form['username']
       password=request.form['password']
       data = open("news.json", encoding="utf-8").read()
       resp = json.loads(data)

       print(login,password)
       for i in range(len(resp)):
           if(resp[i]['login']==login and resp[i]['password']==password):
               use=True

       if(use):
           return redirect('/success')
       else:
           return redirect('/oshibka')
@app.route('/success')
def success():
    user = "Ученик Яндекс.Лицея"
    return render_template('index.html', title='Домашняя страница',
                           username=user)
@app.route('/oshibka')
def oshibka():
    return 'Exception'
if __name__ == '__main__':
    app.run(port=8000, host='127.0.0.1')