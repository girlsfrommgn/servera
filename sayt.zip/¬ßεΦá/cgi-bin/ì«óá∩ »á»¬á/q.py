import os
import pygame
import shutil

pygame.init()

size = width, height = 800, 600

screen = pygame.display.set_mode(size)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        return pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)



all_sprites = pygame.sprite.Group()

sprite = pygame.sprite.Sprite()

sprite.image = load_image("й.png")

sprite.rect = sprite.image.get_rect()
sprite.rect.x = 30
sprite.rect.y = 40

all_sprites.add(sprite)
running = True

while running:
    screen.fill((0, 0, 0))
    pygame.mouse.set_visible(False)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEMOTION:
            x = event.pos
            sprite.rect.x = x[0]
            sprite.rect.y = x[1]

    if (pygame.mouse.get_focused()):
        all_sprites.draw(screen)

    pygame.display.flip()
