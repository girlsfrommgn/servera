import os
import pygame
import random
import shutil

pygame.init()
# размеры окна:
size = width, height = 600, 300
# screen — холст, на котором нужно рисовать:
screen = pygame.display.set_mode(size)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()

    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image.convert_alpha()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))

    return image


list = []
# создадим группу, содержащую все спрайты
all_sprites = pygame.sprite.Group()
# создадим спрайт
# определим его вид
v=-600
sprite = pygame.sprite.Sprite()
sprite.image = pygame.transform.scale(load_image("1.png", colorkey=-1),(600,300))
# и размеры
sprite.rect = sprite.image.get_rect()
sprite.rect.x = v
sprite.rect.y = 0
# добавим спрайт в группу
all_sprites.add(sprite)
running = True
clock = pygame.time.Clock()
while running:
    screen.fill((0, 0, 255))
    if(v<=0):
        v+=int(clock.tick()/1000*600)
    print(v)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    sprite.rect.x=v

    all_sprites.draw(screen)
    pygame.display.flip()
